import React from 'react';

// component import
import Hero from '../../Components/Hero/Hero'

function Home() {
    return (
        <>
            <Hero />
        </>
    )
}

export default Home