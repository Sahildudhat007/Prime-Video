import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom';


// tmdb api key
const API_KEY = '110d18c3a7a47b2f8739f8c719ff1aef';

function SearchBar() {

    const [searchParams] = useSearchParams();
    const query = searchParams.get('q') || '';
    const [results, setResults] = useState([]);

    useEffect(() => {
        if (query) {
            fetch(`https://api.themoviedb.org/3/search/multi?api_key=${API_KEY}&query=${query}`)
                .then(res => res.json())
                .then(data => {
                    setResults(data.results || []);
                })
                .catch(err => console.error('Search error:', err));
        }
    }, [query]);

    return (
        <>
            <section>
                <div className="p-4 text-white">
                    <h2 className="text-xl mb-4">Search Results for: <strong>{query}</strong></h2>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {results.map(item => (
                            <div key={item.id} className="bg-[#1e293b] p-2 rounded">
                                <img
                                    src={`https://image.tmdb.org/t/p/w500${item.poster_path || item.backdrop_path}`}
                                    alt={item.title || item.name}
                                    className="w-full h-60 object-cover rounded"
                                />
                                <p className="mt-2 text-sm">{item.title || item.name}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </>
    )
}

export default SearchBar